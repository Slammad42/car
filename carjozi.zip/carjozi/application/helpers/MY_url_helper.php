<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

if ( ! function_exists('site_url'))
{
	function site_url($uri = '',$lang='')
	{
		$CI =& get_instance();
		$lang = ($lang=='')?$CI->uri->segment(1):$lang;
		if($lang=='')
		{
			$lang=default_lang();
		}
		if($lang=='admin')
			$lang = 'en';

		$final_url = $CI->config->site_url($lang.'/'.$uri);
		//$final_url = str_replace('http://','https://',$final_url);
		return $final_url;
	}
}

if ( ! function_exists('base_url'))
{
	function base_url($uri = '')
	{
		$CI =& get_instance();
		$base_url = $CI->config->base_url($uri);
		//$base_url = str_replace('http://','https://',$base_url);
		return $base_url;
	}
}

// added on version 1.6
if ( ! function_exists('get_the_current_url'))

{

	function get_the_current_url() {
	    
	    $protocol = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
	    $base_url = $protocol . "://" . $_SERVER['HTTP_HOST'];
	    $complete_url =   $base_url . $_SERVER["REQUEST_URI"];
	    
	    return $complete_url;
	     
	}

}
//end

