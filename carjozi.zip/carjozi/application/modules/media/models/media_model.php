<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento admin Controller
 *
 * This class handles user account related functionality
 *
 * @package		Media
 * @subpackage	Media
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'media_model_core.php';
class Media_model extends Media_model_core {

	public function __construct()
	{
		parent::__construct();
	}
}
/* End of file install.php */
/* Location: ./application/modules/media/models/media_model.php */