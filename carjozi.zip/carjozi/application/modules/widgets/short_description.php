<h3 class="widget-title">Intro</h3>
                        <div class="widget-body">
                            <p><b>CarJOZI</b> Ng The platform that lets you buy a car of your choice from dealers arround you, it also gives people the opportunity to make themselves rich by supplying the Car dealers with Buyers</p>
                        </div>