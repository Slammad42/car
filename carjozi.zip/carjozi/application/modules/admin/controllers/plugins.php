<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento plugins Controller
 *
 * This class handles plugins management related functionality
 *
 * @package		Admin
 * @subpackage	plugins
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'plugins_core.php';
class Plugins extends Plugins_core {

	public function __construct()
	{
		parent::__construct();
	}
}