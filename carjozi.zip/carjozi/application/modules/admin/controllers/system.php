<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento system Controller
 *
 * This class handles system management related functionality
 *
 * @package		Admin
 * @subpackage	system
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'system_core.php';
class System extends System_core {

	public function __construct()
	{
		parent::__construct();
	}
}