<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * Memento admin Controller
 *
 * This class handles user account related functionality
 *
 * @package		Show
 * @subpackage	ShowModel
 * @author		webhelios
 * @link		http://webhelios.com
 */
require_once'show_model_core.php';
class Show_model extends Show_model_core {

	public function __construct()
	{
		parent::__construct();
	}
}
/* End of file install.php */
/* Location: ./application/modules/show/models/show_model.php */