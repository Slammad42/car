<h1 class="widget-title"><i class="fa fa-user"></i>&nbsp;PAYMENT</h1>
<div class="row">
    <div class="col-md-12" style="min-height:300px">
      
        <?php if(get_settings('autocon_settings','enable_bank_transfer','No')=='Yes'){?>
        
         <!--start-pricing-tablel-->
<script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
		<script type="text/javascript" src="js/modernizr.custom.53451.js"></script> 

 <script>
						$(document).ready(function() {
						$('.popup-with-zoom-anim').magnificPopup({
							type: 'inline',
							fixedContentPos: false,
							fixedBgPos: true,
							overflowY: 'auto',
							closeBtnInside: true,
							preloader: false,
							midClick: true,
							removalDelay: 300,
							mainClass: 'my-mfp-zoom-in'
						});
																						
						});
				</script>							
 <div class="pricing-plans">
					 <div class="wrap">
					 	
					 	 

						<div class="pricing-grids">
						<div class="pricing-grid1">
							<div class="price-value">
									<h2><a href="#"> STATER</a></h2>
									<h5><span>&#8358;15,000</span></h5>
									<div class="sale-box">
							<span class="on_sale title_shop">PACKAGE</span>
							</div>

							</div>
							<div class="price-bg">
							<ul>
								<li class="whyt"><a href="https://payme.ng/slammad42/MTAwODQ2">Pay Online</a></li>
							
							</ul>
							
							</div>
						</div>
						<div class="pricing-grid1">
							<div class="price-value">
									<h2><a href="#"> MEGA</a></h2>
									<h5><span>&#8358;20,000</span></h5>
									<div class="sale-box">
							<span class="on_sale title_shop">PACKAGE</span>
							</div>

							</div>
							<div class="price-bg">
							<ul>
                            <li class="whyt"><a href="https://payme.ng/slammad42/MTAwODQ3">Pay Online</a></li>
								
							</ul>
							
							</div>
						</div>
						<div class="pricing-grid1">
							<div class="price-value">
									<h2><a href=""> BANK</a></h2>
									
                                    <p style="color:white;">Go to any bank and pay the package amount to this account <br><b>Acct Name:</b> Bello Saidu Isah <br><b>Acct No:</b> 0170641556 <br><b>Bank:</b> GTbank </p>
									<div class="sale-box">
							<span class="on_sale title_shop">STEP</span>
							</div>

							</div>
							
						</div>
						
							<div class="clear"> </div>
				
							</div>
						<div class="clear"> </div>

					</div>
				
				</div>
	<!--//End-pricingplans-->       
                     
        <?php }?>
    </div>    
</div> <!-- /row -->
