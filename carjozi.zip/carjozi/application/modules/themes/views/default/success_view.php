<h1 class="widget-title"><i class="fa fa-user"></i>&nbsp;Confirmation</h1>
<div class="row">
    <div class="col-md-12" style="min-height:300px">
        <div class="alert alert-info">
            <?php echo lang_key('reg_success_message'); ?>
        </div>
    </div>    
</div> <!-- /row -->
