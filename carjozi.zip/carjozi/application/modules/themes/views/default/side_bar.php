<!-- Category Navigation-->
<div class="well">
    <ul class="nav nav-pills nav-stacked">
        <li class="active"><a href="http://geedmo.com/codecanyon/plan/bootstrap.html#"><i class="fa fa-indent"></i>  Categories </a></li>
        <li><a href="http://geedmo.com/codecanyon/plan/bootstrap.html#">
        		<i class="fa fa-tags fa-flip-horizontal"></i> Gif 
                <span class="label label-info pull-right" data-effect="pop">201</span>
            </a>
        </li>
        <li><a href="http://geedmo.com/codecanyon/plan/bootstrap.html#">
        		<i class="fa fa-tags fa-flip-horizontal"></i> Video 
                <span class="label label-info pull-right" data-effect="pop">109</span>
            </a>
        </li>
        <li><a href="http://geedmo.com/codecanyon/plan/bootstrap.html#">
        		<i class="fa fa-tags fa-flip-horizontal"></i> NSFW 
                <span class="label label-info pull-right" data-effect="pop">47</span>
            </a>
        </li>
    </ul>
</div>

<!-- Tab navigation for trendin / hot memes-->
<div class="tabbable">
    <ul class="nav nav-tabs">
        <li class="active"><a href="#tab11" data-toggle="tab"><i class="fa fa-comments-o"></i> Trending</a></li>
        <li class=""><a href="#tab12" data-toggle="tab"><i class="fa fa-calendar"></i> Recent</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" id="tab11">
            <p>
            	<?php for ($i = 0; $i <=3; $i++):?>
                <a href="http://geedmo.com/codecanyon/plan/bootstrap.html#" class="thumbnail col-sm-12">
							<img src="http://d24w6bsrhbeh9d.cloudfront.net/photo/aWZAqP6_460s_v2.jpg" alt="">
                            This is an awfull meme title
				</a>
                <?php endfor;?>
            </p>
        </div>
        <div class="tab-pane" id="tab12">
            <p>
                recent posts h
            </p>
        </div>
    </div>
</div>

<!-- Slider navigation for memes-->
<div class="panel panel-primary" >
    <div class="panel-heading">
        <i class="fa fa-bolt"></i>  Hot memes
    </div>
    <div class="panel-body">
        <div id="myCarousel" class="carousel slide">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class=""></li>
                <li data-target="#myCarousel" data-slide-to="1" class=""></li>
                <li data-target="#myCarousel" data-slide-to="2" class="active"></li>
            </ol>
            <div class="carousel-inner">
                <!-- Slide 1 -->
                <div class="item">
                    <img src="http://d24w6bsrhbeh9d.cloudfront.net/photo/aWZAqP6_460s_v2.jpg" alt="">
                    <div class="carousel-caption caption-right">
                        <a href="http://geedmo.com/codecanyon/plan/bootstrap.html#" class="btn btn-info btn-sm">Read more</a>
                    </div>
                </div>
                <!-- Slide 2 -->
                <div class="item">
                    <img src="http://d24w6bsrhbeh9d.cloudfront.net/photo/aWZAqP6_460s_v2.jpg" alt="">
                    <div class="carousel-caption caption-left">
                        <a href="http://geedmo.com/codecanyon/plan/bootstrap.html#" class="btn btn-danger btn-sm">Read more</a>
                    </div>
                </div>
                <!-- Slide 3 -->
                <div class="item active">
                    <img src="http://d24w6bsrhbeh9d.cloudfront.net/photo/aWZAqP6_460s_v2.jpg" alt="">
                    <div class="carousel-caption">
                        <a href="http://geedmo.com/codecanyon/plan/bootstrap.html#" class="btn btn-danger btn-sm">Read more</a>
                    </div>
                </div>
            </div>
            <a class="left carousel-control" href="http://geedmo.com/codecanyon/plan/bootstrap.html#myCarousel" data-slide="prev">
            <span class="fa fa-prev"></span>
            </a>
            <a class="right carousel-control" href="http://geedmo.com/codecanyon/plan/bootstrap.html#myCarousel" data-slide="next">
            <span class="fa fa-next"></span>
            </a>
        </div>
     </div>
</div>