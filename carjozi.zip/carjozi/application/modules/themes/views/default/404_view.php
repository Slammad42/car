<style type="text/css">
.error404{

}
.error404 h1{

}
.min-height-default{
	height: 400px;
}
</style>
<div class="container">
	<div class="row">
	  <div class="col-md-9 min-height-default">
	    <div class="error404">
	      <h1>Opps, page not found[404]</h1>
	      <a class="btn btn-warning" href="<?php echo site_url();?>">&lt; <?php echo lang_key('home');?></a>
	    </div>
	  </div>
	</div>
</div>	 